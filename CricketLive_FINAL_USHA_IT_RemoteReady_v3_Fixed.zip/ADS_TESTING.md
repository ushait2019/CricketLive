# Cricket Live — Ads testing

The current build uses Unity LevelPlay Android SDK 9.6.0.

Configured:
- App Key: 291bd9bcd
- Banner Ad Unit ID: rfvqbutm8q247lt6

The app now:
- initializes LevelPlay before creating the banner;
- logs initialization and banner load errors;
- retries banner loading after temporary failures;
- keeps the ad slot unobtrusive if inventory is unavailable.

Important: no code can guarantee a live ad impression. Unity recommends enabling LevelPlay test mode/test devices while the app is not yet released to an app store. If test ads appear, the SDK integration is working; production fill can still vary by network, region, account approval, and mediation setup.
