# Channel Hub implementation

This version adds the first working Channel Hub UI to the Android MVP.

## User flow

1. Open a live cricket match.
2. Tap **Watch Live**.
3. The app opens a channel sheet showing the official sources mapped to that match and territory.
4. If a source has an authorized in-app HLS/DASH stream, the app opens `LivePlayerActivity`.
5. If a source is official but does not have an authorized in-app stream, the app does not invent a stream URL. It shows that the source is not connected yet.

## Current demo mappings

The demo BPL match contains T Sports, Nagorik TV and Rabbithole as example Bangladesh broadcaster mappings. These are mapping examples only; no stream URL is embedded in the APK.

## Production requirement

The backend must supply current match-to-channel mappings, territory restrictions, official destination URLs, playback type, and an explicit `inAppPlaybackAllowed` flag. Stream URLs must never be populated unless the content owner/provider has authorized playback in the app.
