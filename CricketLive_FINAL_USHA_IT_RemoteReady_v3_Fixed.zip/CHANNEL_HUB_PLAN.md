# Cricket Channel Hub

The product is a single app where users do not have to manually search the web for a cricket stream.

## User flow

Home
  ↓
LIVE NOW
  ↓
Available cricket channels/streams
  ↓
Tap a channel
  ↓
In-app player when authorized
  OR
Official broadcaster page when in-app embedding is not authorized

## Important rights distinction

The app can aggregate and organize official cricket viewing sources.

It cannot copy, restream, or scrape unauthorized IPTV/streaming feeds.

The channel catalog should be populated from:
- competition/organizer official broadcaster lists,
- broadcaster-owned public live streams,
- explicitly embeddable official players,
- licensed video feeds where the provider permits app playback.

## Example

For ICC Men's T20 World Cup 2026, ICC currently lists Bangladesh rights holders including T Sports and Nagorik TV for linear TV and Rabbithole as a digital platform. The app can use this information to tell the user where the match is officially available. It does not automatically give the app permission to rebroadcast those feeds.

## UX target

The user should see something like:

LIVE CRICKET
--------------------------------
🔴 Bangladesh vs India
   T Sports        [WATCH LIVE]
   Nagorik TV      [WATCH LIVE]
   Rabbithole      [WATCH LIVE]

🔴 Australia vs Pakistan
   Official Source [WATCH LIVE]

The [WATCH LIVE] action chooses the correct official source automatically.
The user does not need to Google the channel separately.

## Ads

The advertisement area remains separate from the player and channel controls.