# Cricket Live Hub v10 — Channel Hub routing

This version makes the channel UI source-aware:

- Authorized HLS/DASH -> Media3 in-app player.
- Authorized YouTube Live -> official YouTube embed surface inside the app.
- Official web/app destination -> external official destination.
- Missing source -> friendly unavailable state; no fake stream link.

The demo channel rows use the official destinations for T Sports, Nagorik TV and Rabbithole. They do **not** claim direct in-app playback because no authorized in-app stream URL has been supplied.

When the backend later returns a rights-holder-authorized YouTube Live URL, set:

- `playbackType = YOUTUBE_LIVE`
- `liveUrl = official YouTube watch URL`
- `isOfficialSource = true`
- `inAppPlaybackAllowed = true`

For an authorized HLS/DASH source, use the same flags with `HLS` or `DASH`.
