# Cricket Live — Final V1 Release Status

## Included

- Package: `com.ushait.cricketlive`
- Version: `1.0.0` / versionCode 100
- Release APK + AAB GitHub Actions workflow
- HOME / LIVE MATCHES / LIVE SCORE / SCHEDULE navigation
- Automatic cricket fixtures/schedule via SportScore
- Live score refresh every 20 seconds while matches are live
- Match detail endpoint through the optional Cloudflare Worker
- Reminder ON/OFF with notification, vibration and alarm channel
- Reminder restoration after reboot/app replacement
- Authorized in-app HLS/DASH/YouTube Live player paths
- Strict match-specific video source filtering
- LevelPlay banner configuration
- USHA IT footer/copyright

## Not included by design

- Unauthorized stream extraction or IPTV scraping
- DRM bypass or rebroadcasting
- Fake/demo live scores in Release builds
- External-browser playback of a match stream
- Automatic acquisition of broadcast rights
- PC/Web Controller (planned for a later version)


Backend bootstrap URL is preconfigured for V1: https://cricket-live-api.ushait2019.workers.dev. The Worker can be replaced/updated tomorrow without rebuilding the APK.
