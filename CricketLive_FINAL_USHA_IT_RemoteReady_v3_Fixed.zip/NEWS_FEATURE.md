# Cricket Live News

- Home navigation is now at the top: Home, Live, Matches, News, Favorites.
- News is displayed inside the app.
- The app refreshes configured public RSS feeds automatically every hour using WorkManager.
- News articles open in an in-app WebView rather than sending the user to a separate browser.
- Default feeds: BBC Sport Cricket, ESPNcricinfo, The Guardian Cricket.
- The feed list can later be moved to the remote admin configuration so the app can change sources without an APK rebuild.
