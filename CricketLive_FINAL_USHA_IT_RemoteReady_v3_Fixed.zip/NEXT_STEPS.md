# Cricket Live Hub: next steps

## Product scope

Cricket only.

Initial focus:
1. Bangladesh cricket
2. BPL
3. International cricket
4. IPL
5. Major T20 leagues
6. Major ICC events

## Technical flow

Android
  ↓
Cloudflare Worker
  ↓
Sportmonks Cricket API
  ↓
Cached normalized match data
  ↓
Android users

## Important

The free provider plan may not cover all requested competitions. We will first prove the full pipeline with available coverage and only consider a paid plan when actual user demand requires it.

Do not put the provider token in the Android project.