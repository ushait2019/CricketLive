# In-app Cricket TV Player

The app now has an AndroidX Media3/ExoPlayer-based player architecture.

Official Android documentation recommends Media3 ExoPlayer for app-level video playback. `PlayerView` provides the video surface and playback controls.

## Supported source types in this first implementation

- HLS `.m3u8`
- DASH `.mpd`

The player accepts a stream URL only when the backend has marked that source as an authorized in-app playback source.

## User experience

Normal:
- video remains inside the app
- standard playback controls are visible
- screen stays awake during playback

Fullscreen:
- player switches to landscape
- system UI is hidden
- user can return with the system back action

## YouTube

Official YouTube live sources use a separate embedded-player implementation. They should not be treated as raw HLS URLs. The project keeps YouTube as a separate source type because Google provides an official IFrame player for embedded playback.

## Advertising

The Monetag SmartLink remains outside the player. No ad overlay will be placed over the play button or playback controls.