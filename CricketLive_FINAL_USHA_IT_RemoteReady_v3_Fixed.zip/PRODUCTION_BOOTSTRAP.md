# Cricket Live — Production Bootstrap

This release is designed so normal users do not manually enter matches, scores, or schedules.

## Automatic data flow

Cricket Live → optional Cloudflare Worker → SportScore API → normalized matches/scores → Cricket Live UI.

If the Worker URL is not configured, the Release APK safely falls back to SportScore's public cricket endpoints directly. This keeps the first test deployment simple. For a larger user base, deploy the Worker so the data is cached centrally and API traffic is controlled.

## One-time setup

1. Deploy `backend/cloudflare-worker.js` to an HTTPS Cloudflare Worker.
2. If remote configuration is needed, bind `CONFIG_KV` and set `ADMIN_TOKEN` as a Worker secret.
3. Set the Worker URL as the app's backend URL through the existing remote-config mechanism, then ship that configured build.
4. Keep the visible `Data from SportScore` attribution in the app while using the free attribution tier. Review SportScore's current terms before commercial/white-label use.
5. Add only broadcast/video sources whose rights holder explicitly authorizes in-app playback.

## Automatic operation after setup

- Fixtures and schedules are retrieved automatically.
- Live status is refreshed automatically.
- Live score details are refreshed every 20 seconds while a match is live.
- General match/schedule data refreshes every 60 seconds while the app is open.
- Match reminders persist and are restored after reboot/app replacement.
- Video sources remain match-ID scoped; the app never substitutes another match's source.

## Important

The APK cannot obtain sports-data credentials or broadcast rights on its own. Those are one-time provider/rights arrangements. No protected `.m3u8` extraction, IPTV scraping, DRM bypass, or unauthorized rebroadcasting is included.
