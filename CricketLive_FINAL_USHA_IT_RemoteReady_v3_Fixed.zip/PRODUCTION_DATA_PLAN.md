# Production data plan

## V1 data provider
Cricket Live V1 uses the SportScore public cricket API through the Cloudflare Worker. The Worker caches the provider response for 60 seconds and returns normalized match data to the app.

The app displays a visible **Data from SportScore** attribution link. SportScore documents a free attribution tier and asks for a visible dofollow attribution; large-scale commercial white-label/attribution-free arrangements should be discussed with SportScore.

## Backend
1. Deploy `backend/cloudflare-worker.js`.
2. Optionally bind `CONFIG_KV` for remote configuration.
3. Set the app's `BACKEND_BASE_URL` in `app/build.gradle.kts` to the Worker HTTPS URL.
4. Build Release.

No Cricbuzz/CREX scraping is used.
