# Cricket Live — Release Build

This project is configured to produce both a release APK and an Android App Bundle (AAB).

- Application ID: `com.ushait.cricketlive`
- Version code: `100`
- Version name: `1.0.0`
- Play Store upload format: `CricketLive.aab`
- APK output: `CricketLive.apk`

The current GitHub Actions workflow builds release artifacts instead of a debug APK.

For Google Play production publishing, the release artifact must be signed with a stable upload key. Keep the same signing key for all future updates.
