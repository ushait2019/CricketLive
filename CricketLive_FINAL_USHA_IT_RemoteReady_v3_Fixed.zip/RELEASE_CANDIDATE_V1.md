# Cricket Live — Release Candidate V1.0.0

This package is the V1 release candidate for closed testing before store publication.

## Included
- Cricket Live branding / USHA IT attribution
- HOME / LIVE MATCHES / LIVE SCORE / SCHEDULE navigation
- In-app authorized HLS/DASH/YouTube Live playback paths
- Match-specific playback checks; no external broadcaster navigation
- Match reminder ON/OFF with notification + vibration
- LevelPlay banner integration
- Release APK/AAB GitHub Actions workflow

## Important before public release
The app currently contains a demo sports repository and the Live Score screen is deliberately marked as not connected to a licensed live-score provider. Do not publish the app as a real-time score product until the licensed production data backend is connected and verified.

Likewise, only explicitly authorized in-app video sources may be configured. The app must not be supplied hidden/protected stream URLs or unauthorized IPTV/HLS sources.

## Build
GitHub Actions accepts either the Android project at repository root or a single source ZIP and produces:
- `CricketLive.apk`
- `CricketLive.aab`
