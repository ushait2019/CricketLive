# Cricket Live — Reminder Feature

- Schedule screen shows an ON/OFF reminder switch for every upcoming match.
- ON schedules a match-start alarm and notification.
- OFF cancels the scheduled alert.
- The alert uses high-priority notification, alarm sound and vibration.
- Notification opens Cricket Live and offers LIVE SCORE / WATCH LIVE actions.
- Android 13+ requests notification permission.
- Android 12+ uses exact alarm when the system allows it; otherwise it uses the best available idle-safe alarm scheduling.
- Reminder state is persisted per match ID.
