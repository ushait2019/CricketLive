package com.ushait.cricketlive

import android.graphics.Color
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import com.unity3d.mediation.LevelPlayAdError
import com.unity3d.mediation.LevelPlayAdInfo
import com.unity3d.mediation.LevelPlayAdSize
import com.unity3d.mediation.banner.LevelPlayBannerAdView
import com.unity3d.mediation.banner.LevelPlayBannerAdViewListener

/**
 * LevelPlay banner controller.
 *
 * The banner is created only after LevelPlay initialization succeeds.
 * Failed loads are retried so a temporary network/no-fill condition does
 * not permanently disable the ad slot for the whole app session.
 */
class LevelPlayBannerController(
    private val activity: MainActivity,
    private val appKey: String = LevelPlayConfig.APP_KEY,
    private val adUnitId: String = LevelPlayConfig.BANNER_AD_UNIT_ID,
    private val enabled: Boolean = true
) {
    companion object {
        private const val TAG = "CricketLiveAds"
        private const val MAX_RETRIES = 3
    }

    private var banner: LevelPlayBannerAdView? = null
    private var retryCount = 0
    private var retryRunnable: Runnable? = null

    fun attach(container: FrameLayout) {
        if (!enabled || appKey.isBlank() || adUnitId.isBlank()) {
            showPlaceholder(container, "Advertisement")
            return
        }

        container.removeAllViews()
        container.visibility = View.VISIBLE

        val config = LevelPlayBannerAdView.Config.Builder()
            .setAdSize(LevelPlayAdSize.BANNER)
            .build()

        val view = LevelPlayBannerAdView(activity, adUnitId, config)

        view.setBannerListener(object : LevelPlayBannerAdViewListener {
            override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                retryCount = 0
                container.visibility = View.VISIBLE
                Log.d(TAG, "Banner loaded: $adInfo")
            }

            override fun onAdLoadFailed(error: LevelPlayAdError) {
                Log.w(TAG, "Banner load failed: ${error.errorCode} ${error.errorMessage}")
                scheduleRetry(container)
            }

            override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {
                Log.d(TAG, "Banner displayed")
            }

            override fun onAdDisplayFailed(adInfo: LevelPlayAdInfo, error: LevelPlayAdError) {
                Log.w(TAG, "Banner display failed: ${error.errorCode} ${error.errorMessage}")
            }

            override fun onAdClicked(adInfo: LevelPlayAdInfo) {
                Log.d(TAG, "Banner clicked")
            }

            override fun onAdExpanded(adInfo: LevelPlayAdInfo) {}
            override fun onAdCollapsed(adInfo: LevelPlayAdInfo) {}
            override fun onAdLeftApplication(adInfo: LevelPlayAdInfo) {}
        })

        view.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(50)
        ).apply {
            gravity = Gravity.CENTER
        }

        container.addView(view)
        banner = view
        view.loadAd()
        Log.d(TAG, "Banner load requested. adUnitId=$adUnitId")
    }

    private fun scheduleRetry(container: FrameLayout) {
        if (retryCount >= MAX_RETRIES || banner == null) return
        retryCount += 1

        val delayMs = when (retryCount) {
            1 -> 2_000L
            2 -> 5_000L
            else -> 10_000L
        }

        retryRunnable?.let { activity.window.decorView.removeCallbacks(it) }
        val task = Runnable {
            if (!activity.isFinishing && !activity.isDestroyed && banner != null) {
                Log.d(TAG, "Retrying banner load #$retryCount")
                banner?.loadAd()
            }
        }
        retryRunnable = task
        activity.window.decorView.postDelayed(task, delayMs)
    }

    private fun showPlaceholder(container: FrameLayout, text: String) {
        container.removeAllViews()
        container.visibility = View.VISIBLE
        container.addView(TextView(activity).apply {
            this.text = text
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(15, 17, 22))
        }, FrameLayout.LayoutParams(-1, dp(50)))
    }

    fun destroy() {
        retryRunnable?.let { activity.window.decorView.removeCallbacks(it) }
        retryRunnable = null
        banner?.destroy()
        banner = null
    }

    private fun dp(value: Int): Int =
        (value * activity.resources.displayMetrics.density).toInt()
}
