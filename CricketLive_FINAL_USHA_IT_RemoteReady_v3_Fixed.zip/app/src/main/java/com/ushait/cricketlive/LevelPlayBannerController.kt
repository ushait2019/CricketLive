package com.ushait.cricketlive

import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import com.unity3d.mediation.LevelPlayAdError
import com.unity3d.mediation.LevelPlayAdInfo
import com.unity3d.mediation.LevelPlayAdSize
import com.unity3d.mediation.banner.LevelPlayBannerAdView
import com.unity3d.mediation.banner.LevelPlayBannerAdViewListener

/** Persistent bottom banner for Cricket Live. */
class LevelPlayBannerController(
    private val activity: MainActivity,
    private val appKey: String = LevelPlayConfig.APP_KEY,
    private val adUnitId: String = LevelPlayConfig.BANNER_AD_UNIT_ID,
    private val enabled: Boolean = true
) {
    private var banner: LevelPlayBannerAdView? = null

    fun attach(container: FrameLayout) {
        if (!enabled || appKey.isBlank() || adUnitId.isBlank()) {
            val placeholder = TextView(activity).apply {
                text = "Advertisement"
                textSize = 11f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setBackgroundColor(Color.rgb(15, 17, 22))
            }
            container.addView(placeholder, FrameLayout.LayoutParams(-1, dp(50)))
            return
        }

        val config = LevelPlayBannerAdView.Config.Builder()
            .setAdSize(LevelPlayAdSize.BANNER)
            .build()

        val view = LevelPlayBannerAdView(
            activity,
            adUnitId,
            config
        )
        view.setBannerListener(object : LevelPlayBannerAdViewListener {
            override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                container.visibility = android.view.View.VISIBLE
            }

            override fun onAdLoadFailed(error: LevelPlayAdError) {
                // Keep the reserved slot unobtrusive when inventory is temporarily unavailable.
            }

            override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayFailed(adInfo: LevelPlayAdInfo, error: LevelPlayAdError) {}
            override fun onAdClicked(adInfo: LevelPlayAdInfo) {}
            override fun onAdExpanded(adInfo: LevelPlayAdInfo) {}
            override fun onAdCollapsed(adInfo: LevelPlayAdInfo) {}
            override fun onAdLeftApplication(adInfo: LevelPlayAdInfo) {}
        })

        view.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(50)
        )
        container.addView(view)
        banner = view
        view.loadAd()
    }

    fun destroy() {
        banner?.destroy()
        banner = null
    }

    private fun dp(value: Int): Int =
        (value * activity.resources.displayMetrics.density).toInt()
}
