package com.ushait.cricketlive

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.ushait.cricketlive.data.ChannelPlaybackType
import com.ushait.cricketlive.data.CricketChannel
import com.ushait.cricketlive.data.RemoteSportsDataRepository
import com.ushait.cricketlive.data.MatchItem
import com.ushait.cricketlive.remote.RemoteAppConfig
import com.ushait.cricketlive.remote.RemoteConfigManager
import com.unity3d.mediation.LevelPlay
import com.unity3d.mediation.LevelPlayInitError
import com.unity3d.mediation.LevelPlayInitListener
import com.unity3d.mediation.LevelPlayInitRequest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    companion object { const val EXTRA_OPEN_MATCH_ID = "open_match_id" }

    private val repository by lazy { RemoteSportsDataRepository(this) }
    private var matches: List<MatchItem> = emptyList()
    private var remoteConfig = RemoteAppConfig()
    private var updateNoticeShownThisSession = false
    private var levelPlayAppKey = LevelPlayConfig.APP_KEY
    private var levelPlayBannerId = LevelPlayConfig.BANNER_AD_UNIT_ID
    private var adController: LevelPlayBannerController? = null
    private var currentPage = "HOME"
    private var currentMatchId: String? = null
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val scoreRefreshRunnable = object : Runnable {
        override fun run() {
            lifecycleScope.launch {
                val live = matches.filter { it.status == "LIVE" }
                if (live.isNotEmpty()) {
                    val updated = live.mapNotNull { repository.getMatchDetail(it) }.associateBy { it.id }
                    if (updated.isNotEmpty()) {
                        matches = matches.map { updated[it.id] ?: it }
                        renderPage(currentPage)
                    }
                }
            }
            scoreRefreshHandler.postDelayed(this, 20_000L)
        }
    }
    private val scoreRefreshHandler = Handler(Looper.getMainLooper())

    private val refreshRunnable = object : Runnable {
        override fun run() {
            lifecycleScope.launch {
                val fresh = repository.getMatches()
                if (fresh.isNotEmpty() || matches.isEmpty()) {
                    matches = fresh
                    renderPage(currentPage)
                }
            }
            refreshHandler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderManager.createNotificationChannel(this)
        requestNotificationPermissionIfNeeded()
        handleConfigIntent(intent)
        lifecycleScope.launch {
            RemoteConfigManager.fetch(this@MainActivity)?.let { remoteConfig = it }
            if (remoteConfig.backendBaseUrl.isNotBlank()) {
                RemoteConfigManager.setBackendBaseUrl(this@MainActivity, remoteConfig.backendBaseUrl)
            }
            matches = repository.getMatches()
            levelPlayAppKey = remoteConfig.levelPlayAppKey.ifBlank { LevelPlayConfig.APP_KEY }
            levelPlayBannerId = remoteConfig.levelPlayBannerAdUnitId.ifBlank { LevelPlayConfig.BANNER_AD_UNIT_ID }
            checkForUpdateOncePerSession()
            initializeLevelPlay()
            runOnUiThread { renderPage(currentPage) }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHandler.removeCallbacks(refreshRunnable)
        scoreRefreshHandler.removeCallbacks(scoreRefreshRunnable)
        refreshHandler.postDelayed(refreshRunnable, 60_000L)
        scoreRefreshHandler.postDelayed(scoreRefreshRunnable, 20_000L)
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(refreshRunnable)
        scoreRefreshHandler.removeCallbacks(scoreRefreshRunnable)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleConfigIntent(intent)
        intent.getStringExtra(EXTRA_OPEN_MATCH_ID)?.let { id ->
            val match = matches.firstOrNull { it.id == id }
            if (match != null) showMatchQuickActions(match)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7001)
        }
    }

    private fun handleConfigIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "cricketlive" && data.host == "config") {
            val url = data.getQueryParameter("url")
            if (!url.isNullOrBlank() && url.startsWith("https://")) {
                RemoteConfigManager.setConfigUrl(this, url)
                Toast.makeText(this, "Remote control connected.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkForUpdateOncePerSession() {
        if (updateNoticeShownThisSession || remoteConfig.latestVersionCode <= BuildConfig.VERSION_CODE) return
        updateNoticeShownThisSession = true
        val mandatory = remoteConfig.minVersionCode > BuildConfig.VERSION_CODE
        val builder = AlertDialog.Builder(this)
            .setTitle("Cricket Live update available")
            .setMessage(remoteConfig.updateMessage.ifBlank { "Version ${remoteConfig.latestVersionName} is available." })
            .setPositiveButton("OK", null)
        if (!mandatory) builder.setNegativeButton("SKIP THIS VERSION", null) else builder.setCancelable(false)
        builder.show()
    }

    private fun initializeLevelPlay() {
        if (!remoteConfig.levelPlayEnabled || levelPlayAppKey.isBlank() || levelPlayBannerId.isBlank()) {
            renderPage("HOME"); return
        }
        LevelPlay.init(this, LevelPlayInitRequest.Builder(levelPlayAppKey).build(), object : LevelPlayInitListener {
            override fun onInitSuccess(configuration: com.unity3d.mediation.LevelPlayConfiguration) { runOnUiThread { renderPage(currentPage) } }
            override fun onInitFailed(error: LevelPlayInitError) { runOnUiThread { renderPage(currentPage) } }
        })
    }

    private fun renderPage(page: String) {
        currentPage = page
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(10,12,16)); setPadding(dp(16), dp(12), dp(16), dp(8)) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(dp(16), bars.top + dp(8), dp(16), bars.bottom + dp(8)); insets
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply { text = "Cricket Live"; textSize = 25f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
        titleBox.addView(TextView(this).apply { text = "Cricket, scores & match alerts"; textSize = 12.5f; setTextColor(Color.LTGRAY); setPadding(0, dp(2), 0, 0) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply { text = "🔔"; textSize = 23f; setPadding(dp(10), 0, dp(4), 0); setOnClickListener { renderPage("SCHEDULE") } })
        root.addView(header)

        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setPadding(0, dp(10), 0, dp(8)) }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("HOME", "LIVE MATCHES", "LIVE SCORE", "SCHEDULE").forEach { label ->
            nav.addView(Button(this).apply {
                text = label; isAllCaps = false; textSize = 10.5f; minWidth = 0; minHeight = dp(40); setPadding(dp(12),0,dp(12),0); setTextColor(Color.WHITE)
                background = rounded(if (page == label) Color.rgb(45,55,70) else Color.rgb(24,27,33), 10)
                setOnClickListener { renderPage(label) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0,0,dp(5),0) })
        }
        navScroll.addView(nav); root.addView(navScroll)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        when (page) {
            "HOME" -> renderHomeContent(content)
            "LIVE MATCHES" -> renderLiveMatches(content)
            "LIVE SCORE" -> renderLiveScore(content)
            "SCHEDULE" -> renderSchedule(content)
        }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        addAdsAndFooter(root)
        setContentView(root)
    }

    private fun renderHomeContent(content: LinearLayout) {
        addSectionTitle(content, "Today's cricket")
        if (matches.isEmpty()) {
            addInfoCard(content, "Live data unavailable", "Cricket Live is connecting to the live cricket-data service. Please check your internet connection and try again.")
        } else {
            matches.forEach { addMatchCard(content, it, compact = true) }
        }
        addInfoCard(content, "Quick check", "Need only the score? Open LIVE SCORE. Want to watch? Open LIVE MATCHES.")
    }

    private fun renderLiveMatches(content: LinearLayout) {
        addSectionTitle(content, "LIVE MATCHES")
        val live = matches.filter { it.status == "LIVE" }
        if (live.isEmpty()) addInfoCard(content, "No live match", "There are no live matches right now. Check SCHEDULE for upcoming games.")
        live.forEach { addMatchCard(content, it, compact = false) }
    }

    private fun renderLiveScore(content: LinearLayout) {
        addSectionTitle(content, "LIVE SCORE")
        val live = matches.filter { it.status == "LIVE" }
        if (live.isEmpty()) {
            addInfoCard(content, "No live score", "Live scorecards will appear here when a match is in progress.")
            return
        }
        live.forEach { match ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(16)); background = rounded(Color.rgb(23,26,32),14) }
            card.addView(TextView(this).apply { text = "🔴 LIVE  •  ${match.competition}"; textSize=11f; setTextColor(Color.rgb(110,220,150)); setTypeface(null,Typeface.BOLD) })
            card.addView(TextView(this).apply { text = "${match.homeTeam}  vs  ${match.awayTeam}"; textSize=18f; setTextColor(Color.WHITE); setTypeface(null,Typeface.BOLD); setPadding(0,dp(8),0,dp(8)) })
            card.addView(TextView(this).apply { text = if (match.scoreText.isNotBlank()) match.scoreText else "Score updating…"; textSize=20f; setTextColor(Color.WHITE); setTypeface(null,Typeface.BOLD) })
            if (match.scoreDetails.isNotBlank() && match.scoreDetails != match.scoreText) {
                card.addView(TextView(this).apply { text = match.scoreDetails; textSize=13f; setTextColor(Color.LTGRAY); setPadding(0,dp(5),0,dp(2)) })
            }
            card.addView(TextView(this).apply { text = if (match.statusText.isNotBlank()) match.statusText else "Live score • auto-refreshing every 20 seconds"; textSize=12f; setTextColor(Color.LTGRAY); setPadding(0,dp(5),0,dp(2)) })
            content.addView(card, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,dp(10)) })
        }
        addInfoCard(content, "Live data", "Scores and fixtures refresh automatically. Data source: SportScore. No Cricbuzz/CREX scraping is used.")
    }

    private fun renderSchedule(content: LinearLayout) {
        addSectionTitle(content, "UPCOMING MATCHES")
        val upcoming = matches.filter { it.status == "SCHEDULED" }
        if (upcoming.isEmpty()) addInfoCard(content, "No upcoming matches", "No upcoming cricket matches were returned by the live data service right now.")
        upcoming.forEach { addScheduleCard(content, it) }
        addSectionTitle(content, "Reminder")
        addInfoCard(content, "Never miss a match", "Turn Reminder ON beside any upcoming match. At match start, Cricket Live will alert you with alarm sound, vibration and notification.")
    }

    private fun addScheduleCard(parent: LinearLayout, match: MatchItem) {
        val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(15),dp(14),dp(15),dp(12)); background=rounded(Color.rgb(23,26,32),14) }
        card.addView(TextView(this).apply { text=match.competition; textSize=11.5f; setTextColor(Color.LTGRAY) })
        card.addView(TextView(this).apply { text="${match.homeTeam}  vs  ${match.awayTeam}"; textSize=18f; setTextColor(Color.WHITE); setTypeface(null,Typeface.BOLD); setPadding(0,dp(6),0,dp(4)) })
        card.addView(TextView(this).apply { text=formatMatchTime(match.startTimeIso); textSize=12.5f; setTextColor(Color.LTGRAY); setPadding(0,0,0,dp(10)) })
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text="Reminder"; textSize=13f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0,-2,1f))
        val toggle=Switch(this).apply { isChecked=ReminderManager.isEnabled(this@MainActivity,match.id); text=if(isChecked) "ON" else "OFF"; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, checked ->
            text=if(checked) "ON" else "OFF"
            ReminderManager.setReminder(this@MainActivity,match.id,match.homeTeam,match.awayTeam,match.startTimeIso,checked)
            if (checked) Toast.makeText(this@MainActivity,"Reminder set for ${match.homeTeam} vs ${match.awayTeam}",Toast.LENGTH_SHORT).show()
        } }
        row.addView(toggle); card.addView(row)
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
    }

    private fun addMatchCard(parent: LinearLayout, match: MatchItem, compact: Boolean) {
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));background=rounded(Color.rgb(23,26,32),14)}
        card.addView(TextView(this).apply{text="${if(match.status=="LIVE") "🔴 LIVE" else "UPCOMING"}  •  ${match.competition}";textSize=11f;setTextColor(if(match.status=="LIVE")Color.rgb(110,220,150):Color.LTGRAY)})
        card.addView(TextView(this).apply{text="${match.homeTeam}  vs  ${match.awayTeam}";textSize=18f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD);setPadding(0,dp(6),0,dp(4))})
        card.addView(TextView(this).apply{text=if(match.status=="LIVE")"Match is live now" else formatMatchTime(match.startTimeIso);textSize=12f;setTextColor(Color.LTGRAY);setPadding(0,0,0,dp(8))})
        val button=Button(this).apply{text=if(match.status=="LIVE")"🔴  Watch Live" else "View Schedule";isAllCaps=false;setOnClickListener{if(match.status=="LIVE")showChannelHub(match) else renderPage("SCHEDULE")}}
        card.addView(button)
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
    }

    private fun addSectionTitle(parent: LinearLayout,title:String){ parent.addView(TextView(this).apply{text=title;textSize=17f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD);setPadding(0,dp(8),0,dp(10))}) }
    private fun addInfoCard(parent: LinearLayout,title:String,text:String){ val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=rounded(Color.rgb(25,30,38),12)};box.addView(TextView(this).apply{text=title;textSize=14f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)});box.addView(TextView(this).apply{text=text;textSize=12f;setTextColor(Color.LTGRAY);setPadding(0,dp(4),0,0)});parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))}) }

    private fun addAdsAndFooter(root:LinearLayout){
        root.addView(TextView(this).apply{text="Advertisement";textSize=10.5f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,dp(6),0,dp(4))})
        val adContainer=FrameLayout(this).apply{setBackgroundColor(Color.rgb(15,17,22))}
        root.addView(adContainer,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(6))})
        adController?.destroy();adController=LevelPlayBannerController(this,levelPlayAppKey,levelPlayBannerId,remoteConfig.levelPlayEnabled);adController?.attach(adContainer)
        val footer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(8),dp(6),dp(8),dp(6))}
        footer.addView(TextView(this).apply{text="Cricket Live";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setTypeface(null,Typeface.BOLD)})
        footer.addView(TextView(this).apply{text="Developed by USHA IT";textSize=10.5f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,dp(2),0,0)})
        footer.addView(TextView(this).apply{text="© 2026 USHA IT. All Rights Reserved.";textSize=10f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,dp(2),0,0)})
        footer.addView(TextView(this).apply{text="Data from SportScore";textSize=9.5f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,dp(3),0,0);setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://sportscore.com/")))}})
        root.addView(footer)
    }

    private fun showMatchQuickActions(match:MatchItem){
        AlertDialog.Builder(this).setTitle("${match.homeTeam} vs ${match.awayTeam}").setMessage("The match has started.").setPositiveButton("LIVE SCORE"){_,_->renderPage("LIVE SCORE")}.setNegativeButton("WATCH LIVE"){_,_->showChannelHub(match)}.show()
    }

    private fun showChannelHub(match: MatchItem) {
        currentMatchId = match.id
        val channels=remoteConfig.channels
            .filter { it.matchId == match.id }
            .filter { it.isOfficialSource && it.inAppPlaybackAllowed && !it.liveUrl.isNullOrBlank() && it.playbackType != ChannelPlaybackType.OFFICIAL_WEB }
        val dialog=android.app.Dialog(this);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(20),dp(22),dp(20));setBackgroundColor(Color.rgb(18,21,27))}
        root.addView(TextView(this).apply{text="LIVE TV • ${match.homeTeam} vs ${match.awayTeam}";textSize=18f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)})
        root.addView(TextView(this).apply{text="Only authorized in-app playback sources can play inside Cricket Live.";textSize=12f;setTextColor(Color.LTGRAY);setPadding(0,dp(5),0,dp(14))})
        if (channels.isEmpty()) {
            root.addView(TextView(this).apply { text = "No authorized in-app stream is available for this match."; textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, dp(8)) })
        } else {
            channels.forEach{addChannelRow(root,it,match.status=="LIVE",dialog)}
        }
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92).toInt(),-2)
    }

    private fun addChannelRow(parent:LinearLayout,channel:CricketChannel,isLive:Boolean,dialog:android.app.Dialog){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=rounded(Color.rgb(28,32,40),10)}
        row.addView(TextView(this).apply{text="🏏  ${channel.name}\n${channel.country}";textSize=14f;setTextColor(Color.WHITE)},LinearLayout.LayoutParams(0,-2,1f))
        val playable=channel.matchId != null && channel.matchId == currentMatchId && channel.isOfficialSource && channel.inAppPlaybackAllowed && !channel.liveUrl.isNullOrBlank() && channel.playbackType != ChannelPlaybackType.OFFICIAL_WEB && isLive
        row.addView(Button(this).apply{text=if(playable)"WATCH LIVE" else "UNAVAILABLE";isAllCaps=false;isEnabled=playable;setOnClickListener{openChannel(channel);dialog.dismiss()}})
        parent.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun openChannel(channel:CricketChannel){
        val url=channel.liveUrl ?: return
        when(channel.playbackType){
            ChannelPlaybackType.HLS,ChannelPlaybackType.DASH->startActivity(Intent(this,LivePlayerActivity::class.java).apply{putExtra(LivePlayerActivity.EXTRA_STREAM_URL,url)})
            ChannelPlaybackType.YOUTUBE_LIVE->startActivity(Intent(this,YouTubePlayerActivity::class.java).apply{putExtra(YouTubePlayerActivity.EXTRA_YOUTUBE_URL,url)})
            ChannelPlaybackType.OFFICIAL_WEB->Toast.makeText(this,"This source does not permit in-app playback.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun rounded(color:Int,radius:Int)=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=dp(radius).toFloat();setColor(color);setStroke(dp(1),Color.rgb(50,56,65))}
    private fun formatMatchTime(iso:String):String=try{java.time.OffsetDateTime.parse(iso).format(java.time.format.DateTimeFormatter.ofPattern("dd MMM • hh:mm a"))}catch(_:Exception){iso}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){
        refreshHandler.removeCallbacksAndMessages(null)
        scoreRefreshHandler.removeCallbacksAndMessages(null)
        adController?.destroy();adController=null
        super.onDestroy()
    }
}
