package com.ushait.cricketlive

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import java.time.OffsetDateTime

object ReminderManager {
    const val CHANNEL_ID = "match_reminders"
    private const val PREFS = "match_reminders"
    private const val KEY_PREFIX = "reminder_"
    private const val HOME_PREFIX = "home_"
    private const val AWAY_PREFIX = "away_"
    private const val START_PREFIX = "start_"

    fun isEnabled(context: Context, matchId: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PREFIX + matchId, false)

    fun setReminder(context: Context, matchId: String, home: String, away: String, startTimeIso: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_PREFIX + matchId, enabled)
            .putString(HOME_PREFIX + matchId, home)
            .putString(AWAY_PREFIX + matchId, away)
            .putString(START_PREFIX + matchId, startTimeIso)
            .apply()

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(context, matchId, home, away)
        alarmManager.cancel(pending)
        if (!enabled) return

        val millis = runCatching { OffsetDateTime.parse(startTimeIso).toInstant().toEpochMilli() }.getOrNull() ?: return
        if (millis <= System.currentTimeMillis()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        }
    }

    fun rescheduleAll(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for ((key, value) in prefs.all) {
            if (!key.startsWith(KEY_PREFIX) || value != true) continue
            val matchId = key.removePrefix(KEY_PREFIX)
            val home = prefs.getString(HOME_PREFIX + matchId, "Cricket") ?: "Cricket"
            val away = prefs.getString(AWAY_PREFIX + matchId, "Match") ?: "Match"
            val start = prefs.getString(START_PREFIX + matchId, null) ?: continue
            setReminder(context, matchId, home, away, start, true)
        }
    }

    private fun pendingIntent(context: Context, matchId: String, home: String, away: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_MATCH_ID, matchId)
            putExtra(EXTRA_HOME, home)
            putExtra(EXTRA_AWAY, away)
        }
        return PendingIntent.getBroadcast(
            context, matchId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return

        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val audio = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val channel = NotificationChannel(CHANNEL_ID, "Match reminders", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alerts when a saved cricket match starts"
            setSound(alarmSound, audio)
            enableVibration(true)
            setBypassDnd(true)
        }
        manager.createNotificationChannel(channel)
    }

    const val EXTRA_MATCH_ID = "match_id"
    const val EXTRA_HOME = "home_team"
    const val EXTRA_AWAY = "away_team"
}
