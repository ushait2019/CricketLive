package com.ushait.cricketlive.data

class DemoSportsDataRepository : SportsDataRepository {
    override suspend fun getMatches(): List<MatchItem> = getDemoMatches()

    fun getDemoMatches(): List<MatchItem> = listOf(
        MatchItem(
            id = "demo-bpl-1",
            competition = "Bangladesh Premier League",
            homeTeam = "BPL Team A",
            awayTeam = "BPL Team B",
            startTimeIso = "2026-10-29T19:00:00+06:00",
            status = "LIVE"
        ),
        MatchItem(
            id = "demo-int-1",
            competition = "International Cricket",
            homeTeam = "Bangladesh",
            awayTeam = "India",
            startTimeIso = "2026-10-29T21:00:00+06:00",
            status = "SCHEDULED"
        ),
        MatchItem(
            id = "demo-ipl-1",
            competition = "Indian Premier League",
            homeTeam = "IPL Team A",
            awayTeam = "IPL Team B",
            startTimeIso = "2026-10-30T20:00:00+06:00",
            status = "SCHEDULED"
        )
    )

    fun getChannelsForMatch(matchId: String): List<CricketChannel> = listOf(
        CricketChannel(
            id = "tsports-live",
            matchId = matchId,
            name = "T Sports",
            country = "Bangladesh • Official Live TV",
            officialUrl = "https://www.tsports.com/live-tv",
            playbackType = ChannelPlaybackType.OFFICIAL_WEB,
            isOfficialSource = true,
            inAppPlaybackAllowed = false
        ),
        CricketChannel(
            id = "toffee-live",
            matchId = matchId,
            name = "Toffee",
            country = "Bangladesh • Official Digital Platform",
            officialUrl = "https://toffeelive.com/en",
            playbackType = ChannelPlaybackType.OFFICIAL_WEB,
            isOfficialSource = true,
            inAppPlaybackAllowed = false
        ),
        CricketChannel(
            id = "rabbithole-live",
            matchId = matchId,
            name = "Rabbithole",
            country = "Bangladesh • Official Live Sports",
            officialUrl = "https://www.rabbitholebd.com/see-all/rabbithole-home/live",
            playbackType = ChannelPlaybackType.OFFICIAL_WEB,
            isOfficialSource = true,
            inAppPlaybackAllowed = false
        ),
        CricketChannel(
            id = "nagorik-tv",
            matchId = matchId,
            name = "Nagorik TV",
            country = "Bangladesh • Official Site",
            officialUrl = "https://nagoriktv.com/",
            playbackType = ChannelPlaybackType.OFFICIAL_WEB,
            isOfficialSource = true,
            inAppPlaybackAllowed = false
        )
    )

}
