package com.ushait.cricketlive.data

/**
 * A legally supplied live-video source.
 *
 * streamUrl should only be populated when the broadcaster/provider has
 * explicitly authorized playback in this app.
 */
data class LiveVideoSource(
    val id: String,
    val channelName: String,
    val country: String,
    val type: VideoType,
    val playbackUrl: String,
    val isOfficial: Boolean = true,
    val embeddingAllowed: Boolean = false
)

enum class VideoType {
    HLS,
    DASH,
    YOUTUBE_LIVE,
    OFFICIAL_WEB_PLAYER
}

data class CricketLiveMatch(
    val match: MatchItem,
    val videoSources: List<LiveVideoSource> = emptyList()
)