package com.ushait.cricketlive.data

import android.content.Context
import com.ushait.cricketlive.BuildConfig
import com.ushait.cricketlive.remote.RemoteConfigManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

class RemoteSportsDataRepository(private val context: Context) : SportsDataRepository {
    override suspend fun getMatches(): List<MatchItem> = withContext(Dispatchers.IO) {
        if (BuildConfig.DEBUG && BuildConfig.DEMO_DATA_ENABLED) {
            return@withContext DemoSportsDataRepository().getDemoMatches()
        }
        val base = RemoteConfigManager.getBackendBaseUrl(context).trimEnd('/')
        val endpoint = if (base.isNotBlank() && !base.contains("YOUR-WORKER")) {
            "$base/v1/matches?date=${LocalDate.now()}"
        } else {
            "https://sportscore.com/api/v1/fixtures/?sport=cricket&date=${LocalDate.now()}&limit=200"
        }
        runCatching {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 10000
                useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode !in 200..299) return@runCatching emptyList()
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val root = JSONObject(body)
            val array = root.optJSONArray("matches") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until array.length()) {
                    val m = array.optJSONObject(i) ?: continue
                    add(
                        MatchItem(
                            id = m.optString("id", ""),
                            providerSlug = m.optString("providerSlug", m.optString("slug", "")),
                            sport = m.optString("sport", "Cricket"),
                            competition = m.optString("competition", m.optString("league", "Cricket")),
                            homeTeam = m.optString("homeTeam", m.optString("home", "TBD")),
                            awayTeam = m.optString("awayTeam", m.optString("away", "TBD")),
                            startTimeIso = m.optString("startTimeIso", m.optString("time", "")),
                            status = normalizeStatus(m.optString("status", "SCHEDULED")),
                            officialWatchUrl = m.optString("officialWatchUrl", "").ifBlank { null },
                            officialWatchLabel = m.optString("officialWatchLabel", "").ifBlank { null },
                            scoreDetails = m.optString("scoreDetails", ""),
                            scoreText = m.optString("scoreText", "").ifBlank {
                                val hs = if (m.has("home_score") && !m.isNull("home_score")) m.optString("home_score") else ""
                                val ascore = if (m.has("away_score") && !m.isNull("away_score")) m.optString("away_score") else ""
                                if (hs.isNotBlank() || ascore.isNotBlank()) "${m.optString("home", "Home")}: $hs  •  ${m.optString("away", "Away")}: $ascore" else ""
                            },
                            statusText = m.optString("statusText", m.optString("status_text", ""))
                        )
                    )
                }
            }.filter { it.id.isNotBlank() && it.startTimeIso.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    suspend fun getMatchDetail(match: MatchItem): MatchItem? = withContext(Dispatchers.IO) {
        val base = RemoteConfigManager.getBackendBaseUrl(context).trimEnd('/')
        val slug = match.providerSlug.ifBlank { match.id }
        val endpoint = if (base.isNotBlank() && !base.contains("YOUR-WORKER")) {
            "$base/v1/match?slug=${java.net.URLEncoder.encode(slug, "UTF-8")}"
        } else {
            "https://sportscore.com/api/v1/match/?sport=cricket&slug=${java.net.URLEncoder.encode(slug, "UTF-8")}"
        }
        runCatching {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7000
                readTimeout = 9000
                useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode !in 200..299) return@runCatching null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val root = JSONObject(body)
            val m = root.optJSONObject("match") ?: root.optJSONObject("data") ?: root
            match.copy(
                providerSlug = m.optString("providerSlug", m.optString("slug", match.providerSlug)),
                status = normalizeStatus(m.optString("status", match.status)),
                scoreText = m.optString("scoreText", match.scoreText),
                scoreDetails = m.optString("scoreDetails", m.optString("scoreText", match.scoreDetails)),
                statusText = m.optString("statusText", match.statusText)
            )
        }.getOrNull()
    }

    private fun normalizeStatus(raw: String): String {
        val value = raw.uppercase()
        return when {
            value.contains("LIVE") || value.contains("IN PROGRESS") -> "LIVE"
            value.contains("FINISHED") || value.contains("COMPLETED") || value.contains("ENDED") -> "FINISHED"
            value.contains("CANCEL") -> "CANCELLED"
            else -> "SCHEDULED"
        }
    }
}
