package com.ushait.cricketlive.data

data class MatchItem(
    val id: String,
    val providerSlug: String = "",
    val sport: String = "Cricket",
    val competition: String,
    val homeTeam: String,
    val awayTeam: String,
    val startTimeIso: String,
    val status: String,
    val scoreText: String = "",
    val statusText: String = "",
    val scoreDetails: String = "",
    val officialWatchUrl: String? = null,
    val officialWatchLabel: String? = null
)

interface SportsDataRepository {
    suspend fun getMatches(): List<MatchItem>
}
