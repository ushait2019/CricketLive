package com.ushait.cricketlive.news

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class NewsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleHourlyRefresh()
        render()
        lifecycleScope.launch {
            runCatching { NewsRepository.refresh(this@NewsActivity) }
            render()
        }
    }

    private fun scheduleHourlyRefresh() {
        val request = PeriodicWorkRequestBuilder<NewsRefreshWorker>(1, TimeUnit.HOURS)
            .setInitialDelay(1, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "cricket-live-news-refresh",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 10)
            setBackgroundColor(Color.rgb(10, 12, 16))
        }
        root.addView(TextView(this).apply {
            text = "Cricket News"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Updated automatically every hour"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 12)
        })

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = NewsRepository.cached(this)
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "News is being updated…"
                textSize = 15f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(0, 60, 0, 60)
            })
        } else {
            items.forEach { item ->
                list.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(14, 13, 14, 13)
                    setBackgroundColor(Color.rgb(23, 26, 32))
                    setOnClickListener { openArticle(item.url) }
                    addView(TextView(this@NewsActivity).apply {
                        text = item.title
                        textSize = 15f
                        setTextColor(Color.WHITE)
                        setTypeface(null, Typeface.BOLD)
                    })
                    addView(TextView(this@NewsActivity).apply {
                        text = item.source
                        textSize = 11.5f
                        setTextColor(Color.LTGRAY)
                        setPadding(0, 6, 0, 0)
                    })
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 9) })
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openArticle(url: String) {
        val web = WebView(this).apply {
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            loadUrl(url)
        }
        setContentView(web)
    }
}
