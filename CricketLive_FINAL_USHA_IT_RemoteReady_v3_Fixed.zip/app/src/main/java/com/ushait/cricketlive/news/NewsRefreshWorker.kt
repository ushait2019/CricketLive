package com.ushait.cricketlive.news

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class NewsRefreshWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = runCatching {
        NewsRepository.refresh(applicationContext)
        Result.success()
    }.getOrElse { Result.retry() }
}
