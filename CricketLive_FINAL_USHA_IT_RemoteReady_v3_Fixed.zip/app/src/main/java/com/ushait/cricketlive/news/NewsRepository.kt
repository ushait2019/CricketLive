package com.ushait.cricketlive.news

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

object NewsRepository {
    private const val PREFS = "cricket_live_news"
    private const val KEY_ITEMS = "items"

    // These are public RSS feeds. The list can later be replaced/extended by the remote admin config.
    private val defaultFeeds = listOf(
        "https://feeds.bbci.co.uk/sport/cricket/rss.xml" to "BBC Sport",
        "https://www.espncricinfo.com/rss/content/story/feeds/0.xml" to "ESPNcricinfo",
        "https://www.theguardian.com/sport/cricket/rss" to "The Guardian"
    )

    suspend fun refresh(context: Context): List<NewsItem> = withContext(Dispatchers.IO) {
        val all = mutableListOf<NewsItem>()
        defaultFeeds.forEach { (feedUrl, source) ->
            runCatching { all += fetchFeed(feedUrl, source) }
        }
        val sorted = all.distinctBy { it.url }.sortedByDescending { it.publishedAt }.take(80)
        save(context, sorted)
        sorted
    }

    fun cached(context: Context): List<NewsItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                NewsItem(o.optString("title"), o.optString("source"), o.optString("url"), o.optLong("publishedAt"))
            }
        }.getOrDefault(emptyList())
    }

    private fun save(context: Context, items: List<NewsItem>) {
        val a = JSONArray()
        items.forEach {
            a.put(JSONObject().apply {
                put("title", it.title)
                put("source", it.source)
                put("url", it.url)
                put("publishedAt", it.publishedAt)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, a.toString()).apply()
    }

    private fun fetchFeed(feedUrl: String, source: String): List<NewsItem> {
        val c = (URL(feedUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "CricketLive/1.0")
            useCaches = false
        }
        if (c.responseCode !in 200..299) return emptyList()
        val stream = c.inputStream
        return stream.use { input ->
            val factory = DocumentBuilderFactory.newInstance().apply {
                setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
                setFeature("http://xml.org/sax/features/external-general-entities", false)
                setFeature("http://xml.org/sax/features/external-parameter-entities", false)
                isXIncludeAware = false
                isExpandEntityReferences = false
            }
            val doc = factory.newDocumentBuilder().parse(input)
            val nodes = doc.getElementsByTagName("item")
            val result = mutableListOf<NewsItem>()
            for (i in 0 until nodes.length) {
                val node = nodes.item(i)
                val children = node.childNodes
                var title = ""
                var link = ""
                var date = ""
                for (j in 0 until children.length) {
                    val child = children.item(j)
                    when (child.nodeName.lowercase(Locale.US)) {
                        "title" -> title = child.textContent.trim()
                        "link" -> link = child.textContent.trim()
                        "pubdate", "published", "updated" -> date = child.textContent.trim()
                    }
                }
                if (title.isNotBlank() && link.startsWith("http")) {
                    result += NewsItem(title, source, link, parseDate(date))
                }
            }
            result
        }.also { c.disconnect() }
    }

    private fun parseDate(value: String): Long {
        if (value.isBlank()) return System.currentTimeMillis()
        return runCatching { java.time.ZonedDateTime.parse(value, java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() }
            .recoverCatching { java.time.Instant.parse(value).toEpochMilli() }
            .getOrDefault(System.currentTimeMillis())
    }
}
