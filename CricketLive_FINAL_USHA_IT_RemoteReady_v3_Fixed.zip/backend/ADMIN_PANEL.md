# USHA IT Desktop Control Panel

The Worker exposes a small server-side control API. A desktop panel can call:

- `GET /v1/config` — public app configuration
- `PUT /v1/admin/config` — replace configuration (requires `Authorization: Bearer <ADMIN_TOKEN>`)
- `GET /v1/matches?date=YYYY-MM-DD` — sports data when `CRICKETDATA_API_KEY` is configured

The Android app can be pointed at `/v1/config` once using:

`cricketlive://config?url=https%3A%2F%2FYOUR-WORKER.workers.dev%2Fv1%2Fconfig`

The LevelPlay Platform API Secret Key and Refresh Token are NOT stored in this project. Keep them as Cloudflare secrets and call LevelPlay's `/partners/publisher/auth` from the server when you later add LevelPlay management to the desktop panel.
