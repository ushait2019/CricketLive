# Deploy the remote-control backend

1. Create a Cloudflare KV namespace named `CONFIG_KV` and put its ID in `wrangler.toml`.
2. Deploy the Worker.
3. Set secret `ADMIN_TOKEN` with a strong random value.
4. Optionally set `CRICKETDATA_API_KEY` for live match data.
5. Open `https://YOUR-WORKER.workers.dev/v1/config` to verify the public config.
6. Connect the already-installed Cricket Live APK once using the deep link:
   `cricketlive://config?url=https%3A%2F%2FYOUR-WORKER.workers.dev%2Fv1%2Fconfig`
7. After that, configuration changes can be made remotely without rebuilding the APK.

Do NOT put `ADMIN_TOKEN`, LevelPlay Secret Key, LevelPlay Refresh Token, or sports-provider tokens in the Android app or GitHub repository.
