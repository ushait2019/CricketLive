# Cricket Live Backend

Cloudflare Worker API for Cricket Live.

## Endpoints

- `GET /health`
- `GET /v1/config`
- `GET /v1/matches`
- `GET /v1/match?slug=<SportScore-slug>`
- `PUT /v1/admin/config` (Bearer `ADMIN_TOKEN`)

The Worker caches the fixture response at the edge and normalizes provider fields into the Android app contract. Live match detail is available through `/v1/match`.

## Provider

SportScore's public API currently offers cricket fixtures, live scores and match details without an API key on its attribution tier. Keep the visible SportScore attribution and review the provider's current terms before commercial/white-label deployment.

The Worker does not discover or extract video streams. Video configuration must contain only sources explicitly authorized for in-app playback.
