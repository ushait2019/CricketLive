/*
 Cricket Live production backend

 Provider: SportScore public API.
 - Free attribution tier, no API key.
 - Keep a visible "Data from SportScore" attribution in the app.
 - For attribution-free / large-scale commercial white-label use, contact SportScore.

 Optional Cloudflare Worker secret:
   ADMIN_TOKEN - protects PUT /v1/admin/config

 KV binding:
   CONFIG_KV - stores key: app-config
*/

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
  "Content-Type": "application/json; charset=utf-8"
};

const DEFAULT_CONFIG = {
  backendBaseUrl: "",
  enabled: true,
  minVersionCode: 100,
  latestVersionCode: 100,
  latestVersionName: "1.0.0",
  updateUrl: "",
  updateMessage: "A new version is available.",
  homeNoticeEnabled: false,
  homeNoticeTitle: "",
  homeNoticeText: "",
  homeNoticeImageUrl: "",
  homeNoticeVideoUrl: "",
  homeNoticeClickUrl: "",
  monetagSmartLinkEnabled: false,
  monetagSmartLinkUrl: "https://uplcm.com/4/12146519",
  levelPlayEnabled: true,
  levelPlayAppKey: "291bd9bcd",
  levelPlayBannerAdUnitId: "rfvqbutm8q247lt6",
  sourceCatalogVersion: 1,
  channels: []
};

export default {
  async fetch(request, env, ctx) {
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
    const url = new URL(request.url);

    if (url.pathname === "/health") return json({ ok: true, service: "cricket-live", provider: "sportscore" });

    if (url.pathname === "/v1/config" && request.method === "GET") {
      const cfg = await readConfig(env);
      if (!cfg.backendBaseUrl) cfg.backendBaseUrl = url.origin;
      return json(cfg);
    }

    if (url.pathname === "/v1/admin/config" && request.method === "PUT") {
      if (!env.ADMIN_TOKEN) return json({ error: "ADMIN_TOKEN is not configured" }, 500);
      const auth = request.headers.get("Authorization") || "";
      if (auth !== `Bearer ${env.ADMIN_TOKEN}`) return json({ error: "Unauthorized" }, 401);
      let payload;
      try { payload = await request.json(); } catch (_) { return json({ error: "Invalid JSON" }, 400); }
      if (!payload || typeof payload !== "object") return json({ error: "Config must be an object" }, 400);
      await writeConfig(env, payload);
      return json({ ok: true, config: payload });
    }

    if (url.pathname === "/v1/matches" && request.method === "GET") {
      return json(await getMatches(ctx));
    }

    if (url.pathname === "/v1/match" && request.method === "GET") {
      const slug = url.searchParams.get("slug") || "";
      if (!slug) return json({ error: "slug is required" }, 400);
      return json(await getMatchDetail(slug));
    }

    return json({ error: "Not found" }, 404);
  }
};

async function getMatches(ctx) {
  const cacheKey = new Request("https://cricket-live-cache.internal/v2/cricket-matches");
  const cache = caches.default;
  const cached = await cache.match(cacheKey);
  if (cached) return await cached.json();

  const today = new Date();
  const tomorrow = new Date(today.getTime() + 86400000);
  const [todayPayload, tomorrowPayload] = await Promise.all([
    fetchSportScoreFixtures(today),
    fetchSportScoreFixtures(tomorrow)
  ]);

  const all = [...todayPayload, ...tomorrowPayload];
  const unique = new Map();
  for (const m of all) unique.set(m.id, m);
  const matches = [...unique.values()].sort((a,b) => new Date(a.startTimeIso) - new Date(b.startTimeIso));
  const result = {
    date: today.toISOString().slice(0,10),
    sport: "Cricket",
    count: matches.length,
    matches,
    dataAttribution: "Data from SportScore",
    providerUrl: "https://sportscore.com/"
  };

  const cachedResponse = new Response(JSON.stringify(result), {
    headers: { ...corsHeaders, "Cache-Control": "public, max-age=60" }
  });
  ctx.waitUntil(cache.put(cacheKey, cachedResponse.clone()));
  return result;
}

async function fetchSportScoreFixtures(date) {
  const day = date.toISOString().slice(0,10);
  const endpoint = `https://sportscore.com/api/v1/fixtures/?sport=cricket&date=${day}&limit=200`;
  const response = await fetch(endpoint, { headers: { "Accept": "application/json" } });
  if (!response.ok) return [];
  const payload = await response.json();
  const rows = Array.isArray(payload.matches) ? payload.matches : (Array.isArray(payload.data) ? payload.data : []);
  return rows.map(normalizeSportScore).filter(Boolean);
}

async function getMatchDetail(slug) {
  const endpoint = `https://sportscore.com/api/v1/match/?sport=cricket&slug=${encodeURIComponent(slug)}`;
  const response = await fetch(endpoint, { headers: { "Accept": "application/json" } });
  if (!response.ok) return { ok: false, error: `provider_${response.status}` };
  const payload = await response.json();
  const match = findMatchObject(payload) || payload.match || payload.data || payload;
  const normalized = normalizeSportScore(match);
  return { ok: true, match: normalized, raw: sanitizeDetail(payload) };
}

function findMatchObject(value) {
  if (!value || typeof value !== "object") return null;
  if ((value.home || value.home_team) && (value.away || value.away_team)) return value;
  if (Array.isArray(value)) {
    for (const item of value) { const found = findMatchObject(item); if (found) return found; }
  } else {
    for (const key of Object.keys(value)) { const found = findMatchObject(value[key]); if (found) return found; }
  }
  return null;
}

function sanitizeDetail(payload) {
  // Keep the endpoint lightweight; the normalized match is the app contract.
  const m = findMatchObject(payload);
  if (!m) return {};
  return {
    home: m.home || m.home_team || "",
    away: m.away || m.away_team || "",
    home_score: m.home_score ?? m.homeScore ?? null,
    away_score: m.away_score ?? m.awayScore ?? null,
    status: m.status || "",
    status_text: m.status_text || m.statusText || "",
    time: m.time || m.start_time || m.date || null,
    slug: m.slug || null
  };
}

function normalizeSportScore(m) {
  if (!m || typeof m !== "object") return null;
  const home = m.home || m.home_team || m.homeTeam || "TBD";
  const away = m.away || m.away_team || m.awayTeam || "TBD";
  const homeScore = m.home_score ?? m.homeScore ?? null;
  const awayScore = m.away_score ?? m.awayScore ?? null;
  const statusText = String(m.status_text || m.statusText || "");
  const statusRaw = String(m.status || "").toLowerCase();
  const isLive = /live|in_play|in-progress|playing|1st|2nd|innings/i.test(statusRaw) || /live|innings|in progress/i.test(statusText);
  const isFinished = /finished|completed|ended|cancelled|postponed|abandoned/i.test(statusRaw) || /won|finished|completed|abandoned/i.test(statusText);
  const status = isLive ? "LIVE" : (isFinished ? "FINISHED" : "SCHEDULED");
  const startTimeIso = normalizeIso(m.time || m.start_time || m.date || m.startTime);
  const slug = String(m.slug || m.match_slug || "");
  const id = String(m.id || m.match_id || slug || `${home}-${away}-${startTimeIso}`);
  return {
    id,
    providerSlug: slug,
    sport: "Cricket",
    competition: String(m.competition || m.league || m.tournament || "Cricket"),
    homeTeam: String(home),
    awayTeam: String(away),
    startTimeIso,
    status,
    scoreText: formatScore(m),
    statusText,
    scoreDetails: formatScore(m),
    homeScore,
    awayScore,
    officialWatchUrl: null,
    officialWatchLabel: null
  };
}

function formatScore(m) {
  const hs = m.home_score ?? m.homeScore;
  const as = m.away_score ?? m.awayScore;
  if (hs == null && as == null) return "";
  return `${m.home || m.home_team || "Home"}: ${hs ?? "-"}  •  ${m.away || m.away_team || "Away"}: ${as ?? "-"}`;
}

function normalizeIso(value) {
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

async function readConfig(env) {
  if (env.CONFIG_KV) {
    const stored = await env.CONFIG_KV.get("app-config", "json");
    if (stored) return stored;
  }
  return structuredClone(DEFAULT_CONFIG);
}

async function writeConfig(env, payload) {
  if (!env.CONFIG_KV) throw new Error("CONFIG_KV is not configured");
  await env.CONFIG_KV.put("app-config", JSON.stringify(payload));
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: corsHeaders });
}
