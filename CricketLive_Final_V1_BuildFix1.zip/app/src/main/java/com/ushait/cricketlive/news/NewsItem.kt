package com.ushait.cricketlive.news

data class NewsItem(
    val title: String,
    val source: String,
    val url: String,
    val publishedAt: Long
)
