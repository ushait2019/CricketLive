# Production Data Plan

## Architecture

Android app
    ↓
Small backend / serverless API
    ↓
Licensed sports-data provider
    ↓
Official broadcaster / "Where to Watch" mapping

The Android app must not contain a permanent sports-data API secret.

## Initial provider direction

Sportmonks is a candidate for production because it provides football and cricket APIs, has a free football tier for development, and paid plans for broader league coverage.

Current published football pricing starts at €29/month for 5 leagues; cricket starts at €29/month for 26 leagues. Coverage and pricing can change, so verify the current plan before purchasing.

Sportmonks' terms allow building apps from its data and monetizing the resulting creation, but do not allow reselling the raw data. Team logos and player images remain subject to their respective copyright owners.

## Important distinction

Sports DATA ≠ sports BROADCAST RIGHTS.

The app can legally show match metadata if the data license permits it. Showing/rebroadcasting a TV or OTT stream requires separate rights.

Therefore:
- Match title, time, score and status → licensed data provider
- "Where to Watch" → official broadcaster/platform URL
- Full video stream inside the app → only when the streaming provider explicitly permits embedding/distribution

## Monetag

Monetag SmartLink remains an advertising destination only:

https://uplcm.com/4/12146519

Do not use it as a fake "Watch Live" destination.

## Next engineering step

Add a small serverless backend that:
1. stores the Sportmonks API token as a server-side secret,
2. requests only the required fixtures,
3. normalizes them into the app's MatchItem format,
4. caches results,
5. sends only public match data to Android.

This keeps the provider token out of the APK and reduces API calls.