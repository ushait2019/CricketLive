package com.ushait.cricketlive.data

data class CricketChannel(
    val id: String,
    val name: String,
    val country: String,
    val logoUrl: String? = null,
    /** Live playback URL only when the rights holder explicitly authorizes it. */
    val liveUrl: String? = null,
    /** Official destination used when direct in-app playback is unavailable. */
    val officialUrl: String? = null,
    val playbackType: ChannelPlaybackType = ChannelPlaybackType.OFFICIAL_WEB,
    val isOfficialSource: Boolean = true,
    val inAppPlaybackAllowed: Boolean = false
)

enum class ChannelPlaybackType {
    HLS,
    DASH,
    YOUTUBE_LIVE,
    OFFICIAL_WEB
}

data class ChannelMatchAvailability(
    val channel: CricketChannel,
    val matchId: String?,
    val isLive: Boolean
)
