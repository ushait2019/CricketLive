package com.ushait.cricketlive.remote

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Remote configuration with a one-time bootstrap URL stored on-device.
 * The URL is intentionally not a server credential. API secrets stay server-side.
 */
object RemoteConfigManager {
    private const val PREFS = "cricket_live_remote"
    private const val KEY_URL = "config_url"
    private const val KEY_BOOTSTRAPPED = "bootstrapped"

    fun getConfigUrl(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_URL, "") ?: ""

    fun setConfigUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_URL, url.trim())
            .putBoolean(KEY_BOOTSTRAPPED, url.isNotBlank())
            .apply()
    }

    suspend fun fetch(context: Context): RemoteAppConfig? = withContext(Dispatchers.IO) {
        val endpoint = getConfigUrl(context)
        if (endpoint.isBlank()) return@withContext null
        try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7000
                readTimeout = 7000
                useCaches = false
            }
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            parse(JSONObject(body))
        } catch (_: Exception) {
            null
        }
    }

    private fun parse(o: JSONObject): RemoteAppConfig = parseRemoteConfig(o)
}
