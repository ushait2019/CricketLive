package com.ushait.cricketlive.remote

import com.ushait.cricketlive.data.ChannelPlaybackType
import com.ushait.cricketlive.data.CricketChannel
import org.json.JSONArray
import org.json.JSONObject

data class RemoteAppConfig(
    val enabled: Boolean = true,
    val minVersionCode: Int = 100,
    val latestVersionCode: Int = 100,
    val latestVersionName: String = "1.0.0",
    val updateUrl: String = "",
    val updateMessage: String = "A new version is available.",
    val homeNoticeEnabled: Boolean = false,
    val homeNoticeTitle: String = "",
    val homeNoticeText: String = "",
    val homeNoticeImageUrl: String = "",
    val homeNoticeVideoUrl: String = "",
    val homeNoticeClickUrl: String = "",
    val monetagSmartLinkEnabled: Boolean = false,
    val monetagSmartLinkUrl: String = "https://uplcm.com/4/12146519",
    val levelPlayEnabled: Boolean = true,
    val levelPlayAppKey: String = "291bd9bcd",
    val levelPlayBannerAdUnitId: String = "rfvqbutm8q247lt6",
    val sourceCatalogVersion: Int = 1,
    val channels: List<CricketChannel> = emptyList()
)

fun parseRemoteConfig(o: JSONObject): RemoteAppConfig {
    val channels = mutableListOf<CricketChannel>()
    val array = o.optJSONArray("channels") ?: JSONArray()
    for (i in 0 until array.length()) {
        val c = array.optJSONObject(i) ?: continue
        val playback = runCatching { ChannelPlaybackType.valueOf(c.optString("playbackType", "OFFICIAL_WEB")) }
            .getOrDefault(ChannelPlaybackType.OFFICIAL_WEB)
        channels += CricketChannel(
            id = c.optString("id", "source-$i"),
            name = c.optString("name", "Official Source"),
            country = c.optString("country", "Official"),
            officialUrl = c.optString("officialUrl", "").ifBlank { null },
            liveUrl = c.optString("liveUrl", "").ifBlank { null },
            playbackType = playback,
            isOfficialSource = c.optBoolean("isOfficialSource", true),
            inAppPlaybackAllowed = c.optBoolean("inAppPlaybackAllowed", false)
        )
    }
    return RemoteAppConfig(
        enabled = o.optBoolean("enabled", true),
        minVersionCode = o.optInt("minVersionCode", 100),
        latestVersionCode = o.optInt("latestVersionCode", 100),
        latestVersionName = o.optString("latestVersionName", "1.0.0"),
        updateUrl = o.optString("updateUrl", ""),
        updateMessage = o.optString("updateMessage", "A new version is available."),
        homeNoticeEnabled = o.optBoolean("homeNoticeEnabled", false),
        homeNoticeTitle = o.optString("homeNoticeTitle", ""),
        homeNoticeText = o.optString("homeNoticeText", ""),
        homeNoticeImageUrl = o.optString("homeNoticeImageUrl", ""),
        homeNoticeVideoUrl = o.optString("homeNoticeVideoUrl", ""),
        homeNoticeClickUrl = o.optString("homeNoticeClickUrl", ""),
        monetagSmartLinkEnabled = o.optBoolean("monetagSmartLinkEnabled", false),
        monetagSmartLinkUrl = o.optString("monetagSmartLinkUrl", "https://uplcm.com/4/12146519"),
        levelPlayEnabled = o.optBoolean("levelPlayEnabled", true),
        levelPlayAppKey = o.optString("levelPlayAppKey", "291bd9bcd"),
        levelPlayBannerAdUnitId = o.optString("levelPlayBannerAdUnitId", "rfvqbutm8q247lt6"),
        sourceCatalogVersion = o.optInt("sourceCatalogVersion", 1),
        channels = channels
    )
}
