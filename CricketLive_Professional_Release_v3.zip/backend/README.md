# Backend contract

The Android app should eventually call an endpoint such as:

GET /v1/matches?date=YYYY-MM-DD&sport=cricket

Response:

{
  "matches": [
    {
      "id": "provider-match-id",
      "sport": "Cricket",
      "competition": "BPL",
      "homeTeam": "Team A",
      "awayTeam": "Team B",
      "startTimeIso": "2026-10-29T19:00:00+06:00",
      "status": "LIVE",
      "officialWatchUrl": "https://official-broadcaster.example/...",
      "officialWatchLabel": "Watch on Official Platform"
    }
  ]
}

The provider API key must be stored as a cloud secret, never in this Android repository.