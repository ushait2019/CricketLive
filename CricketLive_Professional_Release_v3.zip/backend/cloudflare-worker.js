/*
 Cricket Live backend / remote controller

 Secrets (Cloudflare Worker secrets):
   ADMIN_TOKEN       - required for PUT /v1/admin/config
   SPORTMONKS_TOKEN  - optional; required only for /v1/matches

 KV binding:
   CONFIG_KV (recommended) stores key: app-config

 Public:
   GET /health
   GET /v1/config
   GET /v1/matches?date=YYYY-MM-DD

 Admin:
   PUT /v1/admin/config
   Authorization: Bearer <ADMIN_TOKEN>
*/

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
  "Content-Type": "application/json; charset=utf-8"
};

const DEFAULT_CONFIG = {
  enabled: true,
  minVersionCode: 100,
  latestVersionCode: 100,
  latestVersionName: "1.0.0",
  updateUrl: "",
  updateMessage: "A new version is available.",
  homeNoticeEnabled: false,
  homeNoticeTitle: "",
  homeNoticeText: "",
  homeNoticeImageUrl: "",
  homeNoticeVideoUrl: "",
  homeNoticeClickUrl: "",
  monetagSmartLinkEnabled: false,
  monetagSmartLinkUrl: "https://uplcm.com/4/12146519",
  levelPlayEnabled: true,
  levelPlayAppKey: "291bd9bcd",
  levelPlayBannerAdUnitId: "rfvqbutm8q247lt6",
  sourceCatalogVersion: 1,
  channels: [
    { id:"tsports-live", name:"T Sports", country:"Bangladesh • Official Live TV", officialUrl:"https://www.tsports.com/live-tv", playbackType:"OFFICIAL_WEB", isOfficialSource:true, inAppPlaybackAllowed:false },
    { id:"toffee-live", name:"Toffee", country:"Bangladesh • Official Digital Platform", officialUrl:"https://toffeelive.com/en", playbackType:"OFFICIAL_WEB", isOfficialSource:true, inAppPlaybackAllowed:false },
    { id:"rabbithole-live", name:"Rabbithole", country:"Bangladesh • Official Live Sports", officialUrl:"https://www.rabbitholebd.com/see-all/rabbithole-home/live", playbackType:"OFFICIAL_WEB", isOfficialSource:true, inAppPlaybackAllowed:false },
    { id:"nagorik-tv", name:"Nagorik TV", country:"Bangladesh • Official Site", officialUrl:"https://nagoriktv.com/", playbackType:"OFFICIAL_WEB", isOfficialSource:true, inAppPlaybackAllowed:false }
  ]
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
    const url = new URL(request.url);

    if (url.pathname === "/health") return json({ ok: true, service: "cricket-live" });

    if (url.pathname === "/v1/config" && request.method === "GET") {
      return json(await readConfig(env));
    }

    if (url.pathname === "/v1/admin/config" && request.method === "PUT") {
      if (!env.ADMIN_TOKEN) return json({ error: "ADMIN_TOKEN is not configured" }, 500);
      const auth = request.headers.get("Authorization") || "";
      if (auth !== `Bearer ${env.ADMIN_TOKEN}`) return json({ error: "Unauthorized" }, 401);
      let payload;
      try { payload = await request.json(); } catch (_) { return json({ error: "Invalid JSON" }, 400); }
      if (!payload || typeof payload !== "object") return json({ error: "Config must be an object" }, 400);
      await writeConfig(env, payload);
      return json({ ok: true, config: payload });
    }

    if (url.pathname !== "/v1/matches" || request.method !== "GET") return json({ error: "Not found" }, 404);
    if (!env.SPORTMONKS_TOKEN) return json({ error: "SPORTMONKS_TOKEN is not configured" }, 500);

    const date = url.searchParams.get("date") || new Date().toISOString().slice(0, 10);
    const endpoint = `https://cricket.sportmonks.com/api/v2.0/fixtures/date/${encodeURIComponent(date)}?api_token=${encodeURIComponent(env.SPORTMONKS_TOKEN)}&include=participants;scores;state;league;venue;tvStations`;
    const response = await fetch(endpoint);
    if (!response.ok) return json({ error: "Sports provider request failed", providerStatus: response.status }, 502);
    const payload = await response.json();
    const fixtures = Array.isArray(payload.data) ? payload.data : [];
    return json({ date, sport: "Cricket", count: fixtures.length, matches: fixtures.map(normalizeFixture).filter(Boolean) });
  }
};

async function readConfig(env) {
  if (env.CONFIG_KV) {
    const stored = await env.CONFIG_KV.get("app-config", "json");
    if (stored) return stored;
  }
  return DEFAULT_CONFIG;
}

async function writeConfig(env, payload) {
  if (!env.CONFIG_KV) throw new Error("CONFIG_KV is not configured");
  await env.CONFIG_KV.put("app-config", JSON.stringify(payload));
}

function normalizeFixture(fixture) {
  const participants = Array.isArray(fixture.participants) ? fixture.participants : [];
  const home = participants.find(p => p.meta?.location === "home") || participants[0];
  const away = participants.find(p => p.meta?.location === "away") || participants[1];
  return {
    id: String(fixture.id),
    sport: "Cricket",
    competition: fixture.league?.name || "Cricket",
    homeTeam: home?.name || "TBD",
    awayTeam: away?.name || "TBD",
    startTimeIso: fixture.starting_at || null,
    status: fixture.state?.name || "SCHEDULED",
    officialWatchUrl: null,
    officialWatchLabel: null
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: corsHeaders });
}
